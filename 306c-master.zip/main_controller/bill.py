class bill:
    def __init__(self,customer,room_no,total_fee):
        self.customer=customer
        self.room_no=room_no
        self.total_fee=total_fee

    def print_bill(self,room_no):
        return 0