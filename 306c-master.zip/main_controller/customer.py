class customer:
    def __init__(self,id,room_no,total_fee):
        self.id=id
        self.room_no=room_no
        self.total_fee=total_fee

    def get_total_fee(self):
        return 0

    def get_detailed_record(self):
        return 0