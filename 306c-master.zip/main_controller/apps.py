from django.apps import AppConfig


class MainControllerConfig(AppConfig):
    name = 'main_controller'
