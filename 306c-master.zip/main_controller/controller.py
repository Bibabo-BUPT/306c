class controller:
    def power_on(self,room_no,temper):
        return 1

    def temper_change(self,room_no,temper):
        return 0

    def change_target_temper(self,room_no,target_temper):
        return 0

    def change_speed(self,room_no,speed):
        return 0

    def show_fee(self,room_no,time):
        return 0

    def power_off(self,room_no,time):
        return 0

    def print_bill(self,room_no):
        return 0

    def print_daily_record(self,room_no,record_type):
        return 0

    def print_weekly_record(self, room_no, record_type):
        return 0

    def power_on(self):
        return 0

    def set_default_temper(self,default_temper):
        return 0

    def set_default_mode(self,default_mode):
        return 0

    def set_default_speed(self,default_speed):
        return 0

    def set_accounting_rule(self,low,mid,high):
        return 0

    def find_ac(self,room_no):
        return 0

    def power_off(self):
        return 0

    def create_sq(self):
        return 0

    def create_dq(self):
        return 0

    def create_dr(self):
        return 0

    def create_wr(self):
        return 0

    def create_bill(self):
        return 0

    def create_detaild_record(self):
        return 0
